
public class Punteggio {
private int punti;
public Punteggio()
{
	
}
public void setPunti(int punti) {
	this.punti = punti;
}
public void AggiungiPunti(int punti)
{
	this.punti=punti;
}
public int getPunti()
{

	return punti;
}
}
