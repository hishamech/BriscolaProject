import java.util.LinkedList;

public class Computer extends Punteggio{
@SuppressWarnings("rawtypes")
private LinkedList cards;
private Carta briscola;
private int selez;
final static int primaCarta=0;
final static int secondaCarta=1;
final static int terzaCarta=2;
public Computer()
{
	
}
@SuppressWarnings("unchecked")
public void aggiungiCarta(Carta c)
{
	cards.add(c);
}
public Carta getCard(int index)
{
	return (Carta)cards.get(index);
	
}
public void setBriscola(Carta c)
{
	briscola=c;
}
public int getNCarte()
{
	return cards.size();
}
public void removeCard(int index)
{
cards.remove(index);	
}
public void setSelectedCard(int selez)
{
	this.selez=selez;
}
public int getSelectedCard()
{
	return selez;
}
public Carta PlayFirst()
{
	for (int i=0; i<cards.size(); i++)
	{
		Carta c=getCard(i);
	int indexComputer=c.getIndex();
	int semeComputer=c.getSeme();
	int semeBriscola=briscola.getSeme();
	int valoreComputer=c.getValore();
	if (semeComputer!=semeBriscola)
	{
		if (valoreComputer<10)
		{
			removeCard(i);
		setSelectedCard(i);
		return c;
		}
		else {
if (i==terzaCarta)
{
	removeCard(i);
	setSelectedCard(i);
	return c;
}
		}
	}
	
	}
	int rando=(int)Math.random()*3;
	Carta c=getCard(rando);
	removeCard(rando);
	setSelectedCard(rando);
	return c;
}

public Carta playSecond(Carta giocatore)
{
	for (int i=0; i<cards.size(); i++)
	{
		Carta c=getCard(i);
		int indexComputer=c.getIndex();
		int indexGiocatore=giocatore.getIndex();
		int semeComputer=c.getSeme();
		int semeGiocatore=giocatore.getSeme();
		int semeBriscola=briscola.getIndex();
		int valoreComputer=c.getValore();
		int valoreGiocatore=giocatore.getValore();
		if (semeGiocatore!=semeBriscola)
		{
			if (semeComputer==semeGiocatore)
			{
				if (indexComputer>indexGiocatore)
				{
					removeCard(i);
					setSelectedCard(i);
					return c;
				}
				else {
				if (valoreGiocatore>=10)
				{
					if (semeComputer==semeBriscola)
					{
						removeCard(i);
						setSelectedCard(i);
						return c;
					}
				}
				if (valoreComputer<10)
				{
					if (i==terzaCarta)
					{
						removeCard(i);
						setSelectedCard(i);
						return c;
					}
				}
				}
			}		
			
				
				else {
				if (semeComputer!=semeBriscola)
				{
					if (valoreComputer<10)
					{
						removeCard(i);
						setSelectedCard(i);
						return c;
					}
				}
			}
		}			
					}
	int rando=(int)Math.random()*3;
	Carta c=getCard(rando);
removeCard(rando);
setSelectedCard(rando);
return c;

}


}
