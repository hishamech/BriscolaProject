import java.util.LinkedList;

public class Mazzo {
@SuppressWarnings("rawtypes")
private LinkedList cards=new LinkedList();
private int nc=40;
private String tipo;
final String[] carte={"due","quattro","cinque","sei","sette","fante","cavallo","re","tre","asso"};
private final String[] semi= {"denari","coppe","spade","bastoni"};
private final int val[]= {0,0,0,0,0,2,3,4,10,11};
@SuppressWarnings("unchecked")
public Mazzo(String tipo)
{
this.tipo=tipo;	
for (int i=0; i<10; i++)
{
	for (int j=0; j<4; j++)
	{
		Carta d=new Carta(i, j, val[i]);
cards.add(d);	
	}
}
}
public Carta prendCarta()
{
	int rando=(int)(Math.random()*nc);
Carta c=(Carta)cards.get(rando);
cards.remove(rando);
return c;
}
public int getNc()
{
	return nc;
}
public String getTipo()
{
	return tipo;
}
public boolean isLastRound()
{
	if (nc>1)
	{
		return false;
	}
	return true;
}
public boolean isFinito()
{
	if (nc>0)
	{
		return false;
	}
return true;
}
}