
public class Carta {
	private int index=0;
private int seme;
private int valore=0;

public Carta(int index, int seme, int valore) {
	this.index=index;
this.seme = seme;
	this.valore = valore;
}
public int getSeme() {
	return seme;
}
public int getValore() {
	return valore;
}
public int getIndex() {
	return index;
}

}
