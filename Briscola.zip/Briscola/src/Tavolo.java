import java.util.LinkedList;
public class Tavolo {
@SuppressWarnings("rawtypes")
private static LinkedList cards;
@SuppressWarnings("rawtypes")
public Tavolo(String tipo)
{
	cards=new LinkedList();
	
}
@SuppressWarnings("unchecked")
public void aggiungiCarta(Carta c)
{
	cards.add(c);
	
}
@SuppressWarnings("unchecked")

public void setBriscola(Carta c)
{
Carta d=new Carta(0, 0, 0);	
cards.add(d);
cards.add(c);
cards.add(d);

}
public static Carta getCard(int index)
{
	return (Carta)cards.get(index);
}
public static void removeCard(int index)
{
cards.remove(index);	
}
@SuppressWarnings("unchecked")

public void cancBriscola()
{
	Carta c=new Carta(0, 0, 0);
	cards.set(1, c);
}
}
