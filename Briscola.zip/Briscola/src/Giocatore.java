import java.util.LinkedList;

public class Giocatore extends Punteggio {
    @SuppressWarnings("rawtypes")
	private LinkedList cards = new LinkedList();
    private Carta briscola;
public Giocatore()
{
	
}
@SuppressWarnings("unchecked")
public void addCard(Carta c) {
    cards.add(c);
}
public Carta getCard(int index) {
    return (Carta)cards.get(index);
}
    
public void removeCard(int index) {
    cards.remove(index);
}

public int getNCarte() {
    return cards.size();
}

public boolean carteFinite() {
    if( cards.size() == 0 ) {
        return true;
    }
    
    return false;
}


}
